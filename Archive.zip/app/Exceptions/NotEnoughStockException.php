<?php

namespace App\Exceptions;

use Exception;

class NotEnoughStockException extends Exception
{
    //
}
